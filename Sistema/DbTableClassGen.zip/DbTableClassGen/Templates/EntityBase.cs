﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Linq;
using LibDB2;
using DbEntidades.Operators;

namespace DbEntidades.Entities
{
    public partial class <TableName>
    {
<properties>
        public <TableName>()
        {
            <identity> = -1;
<DEFAULT>
        }

<FK>

<FKR>

<BENULL>
    }
}

