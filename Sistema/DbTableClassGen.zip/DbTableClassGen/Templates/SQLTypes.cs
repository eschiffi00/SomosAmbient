using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using DbEntidades.Entities;
using LibDB2;
using System.Collections;

namespace DbEntidades
{
    <SQLTypeClass>
}

